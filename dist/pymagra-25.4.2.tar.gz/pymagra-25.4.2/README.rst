Pymagra
=======

**Pymagra** is a Python program to display and treat potential field data, especially those obtained with Geometics gradiometer.

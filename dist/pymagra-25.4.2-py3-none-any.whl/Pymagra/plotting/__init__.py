# -*- coding: utf-8 -*-
# from .plotting import plot, newWindow

# print(f"Invoking __init__.py for {__name__}")

# from . import floating_plots
# from .main_window import mainWindow
from .new_window import newWindow

__all__ = ["newWindow"]
